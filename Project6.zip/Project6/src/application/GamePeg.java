package application;

import javafx.scene.paint.Color;

public abstract class GamePeg {
	
	public abstract Color getColor();
	public abstract String toString();
}
